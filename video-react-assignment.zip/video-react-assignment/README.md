# video-react


Video.React is a web video player built from the ground up for an HTML5 world using React library.

Please check it out.

Gourav Agrawal

